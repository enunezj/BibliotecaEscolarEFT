
@echo off
cd /d "%~dp0"

if not exist "db.properties" (
    echo ERROR: Falta el archivo db.properties.
    echo.
    echo Copia db.properties.example como db.properties
    echo y configura la conexion con MySQL.
    echo.
    pause
    exit /b 1
)

where java >nul 2>&1

if errorlevel 1 (
    echo ERROR: Java no esta disponible.
    echo Instala Java 21 o superior y configura PATH.
    pause
    exit /b 1
)

java -jar "BibliotecaEscolarEFT.jar"

if errorlevel 1 pause
